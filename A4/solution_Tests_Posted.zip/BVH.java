import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BVH implements Iterable<Circle>{
    Box boundingBox;

    BVH child1;
    BVH child2;

    Circle containedCircle;

    public BVH(int a, int b, int c, int d, int e, int f, int g) {
    }

    public BVH(ArrayList<Circle> circles) {
        this.boundingBox = buildTightBoundingBox(circles);
        ArrayList<Circle>[] split = split(circles, this.boundingBox);

        // base case
        if (circles.size() == 1) {
            this.containedCircle = circles.get(0);
            return;
        }

        // recursive step
        if (split[0].size() > 0) {
            this.child1 = new BVH(split[0]);
        }
        if (split[1].size() > 0) {
            this.child2 = new BVH(split[1]);
        }
    }

    public void draw(Graphics2D g2) {
        this.boundingBox.draw(g2);
        if (this.child1 != null) {
            this.child1.draw(g2);
        }
        if (this.child2 != null) {
            this.child2.draw(g2);
        }
    }

    // todo for students
    public static ArrayList<Circle>[] split(ArrayList<Circle> circles, Box boundingBox) {
        ArrayList<Circle> first = new ArrayList<>();
        ArrayList<Circle> second = new ArrayList<>();

        if (boundingBox.getWidth() > boundingBox.getHeight()) {
            for (Circle c : circles) {
                if (c.position.x < boundingBox.getMidX()) {
                    first.add(c);
                } else {
                    second.add(c);
                }
            }
        } else {
            for (Circle c : circles) {
                if (c.position.y < boundingBox.getMidY()) {
                    first.add(c);
                } else {
                    second.add(c);
                }
            }
        }
     
        return new ArrayList[]{first, second};
        
    }

    // returns the smallest possible box which fully encloses every circle in circles
    public static Box buildTightBoundingBox(ArrayList<Circle> circles) {
        Vector2 bottomLeft = new Vector2(Float.POSITIVE_INFINITY);
        Vector2 topRight = new Vector2(Float.NEGATIVE_INFINITY);

        for (Circle c : circles) {
            bottomLeft = Vector2.min(bottomLeft, c.getBoundingBox().bottomLeft);
            topRight = Vector2.max(topRight, c.getBoundingBox().topRight);
        }

        return new Box(bottomLeft, topRight);
    }

    // METHODS BELOW RELATED TO ITERATOR

    @Override
    public Iterator<Circle> iterator() {
        return new BVHIterator(this);
    }

    public class BVHIterator implements Iterator<Circle> {
        List<Circle> circles;   // stores all circles within this BVH
        int pointer;            // keeps track of circles that have been iterated over

        public BVHIterator(BVH bvh) {
            circles = new ArrayList<>();
            this.populateCircles(bvh);
            pointer = 0;
        }

        // Fills circles by visiting each leaf node recursively
        public void populateCircles(BVH bvh) {
            // base case, this is a leaf node
            if (bvh.containedCircle != null) {
                circles.add(bvh.containedCircle);
            }
            else {
                if (bvh.child1 != null)
                    populateCircles(bvh.child1);
                if (bvh.child2 != null)
                    populateCircles(bvh.child2);
            }
        }


        @Override
        public boolean hasNext() {
            return pointer != circles.size();
        }

        @Override
        public Circle next() {
            return circles.get(pointer++);
        }
    }
}