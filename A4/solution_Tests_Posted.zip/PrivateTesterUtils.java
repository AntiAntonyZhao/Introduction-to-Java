import java.util.ArrayList;
import java.util.HashSet;

public class PrivateTesterUtils {
    //private should not be included in exposed test
    public static HashSet<ContactResult> getContactsNaive(ArrayList<Circle> circles) {
        HashSet<ContactResult> contacts = new HashSet<>();
        for (Circle c1 : circles) {
            for (Circle c2 : circles) {
                if (c1.id == c2.id) {
                    continue;
                }

                ContactResult cr = c1.isContacting(c2);
                if (cr == null) {
                    continue;
                }

                contacts.add(cr);
            }
        }
        return contacts;
    }

    public static BVH constructBVH(ArrayList<Circle> circles) {
        Box boundingBox = buildTightBoundingBox(circles);
        ArrayList<Circle>[] split = split(circles, boundingBox);

        BVH node = new BVH(1,2,3,4,5,6,7);
        node.boundingBox = boundingBox;

        // base case
        if (circles.size() == 1) {
            node.containedCircle = circles.get(0);
            return node;
        }

        // recursive step
        if (split[0].size() > 0) {
            node.child1 = constructBVH(split[0]);
        }
        if (split[1].size() > 0) {
            node.child2 = constructBVH(split[1]);
        }

        return node;
    }

    public static ArrayList<Circle>[] split(ArrayList<Circle> circles, Box boundingBox) {
        ArrayList<Circle> first = new ArrayList<>();
        ArrayList<Circle> second = new ArrayList<>();

        if (boundingBox.getWidth() > boundingBox.getHeight()) {
            for (Circle c : circles) {
                if (c.position.x < boundingBox.getMidX()) {
                    first.add(c);
                } else {
                    second.add(c);
                }
            }
        } else {
            for (Circle c : circles) {
                if (c.position.y < boundingBox.getMidY()) {
                    first.add(c);
                } else {
                    second.add(c);
                }
            }
        }

        return new ArrayList[]{first, second};
    }

    // returns the smallest possible box which fully encloses every circle in circles
    public static Box buildTightBoundingBox(ArrayList<Circle> circles) {
        Vector2 bottomLeft = new Vector2(Float.POSITIVE_INFINITY);
        Vector2 topRight = new Vector2(Float.NEGATIVE_INFINITY);

        for (Circle c : circles) {
            bottomLeft = Vector2.min(bottomLeft, c.getBoundingBox().bottomLeft);
            topRight = Vector2.max(topRight, c.getBoundingBox().topRight);
        }

        return new Box(bottomLeft, topRight);
    }

}
