package a3;
import java.io.*;

public class Maze {
	private final int dimension = 15;
	public int counter = 0;

	// Checks if we can move to (x,y)
	boolean canMove(char maze[][], boolean found, int x, int y) {
		if(found) {
			return (x >= 0 && x < dimension && y >= 0 && y < dimension && (maze[x][y] == '.' || maze[x][y] == '0'));
		} else {
			return (x >= 0 && x < dimension && y >= 0 && y < dimension && (maze[x][y] == '.' || maze[x][y] == 'k'));
		}
	}

	/* This function solves the Maze problem using
       Backtracking. It mainly uses solveMazeUtil()
       to solve the problem. It returns false if no
       path is possible, otherwise return true and
       prints the path in the form of '.'s. Please note
       that there may be more than one solutions, this
       function prints one of the feasible solutions.*/
	boolean solveMaze(char maze[][]) {

		if (!solveMazeUtil(maze, false, 0, 1)) {
			System.out.print("Solution doesn't exist\n");
			return false;
		}

		return true;
	}

	// A recursive function to solve Maze problem
	boolean solveMazeUtil(char maze[][], boolean found, int x, int y) {
		++counter;
		// if (x, y) is the exit, and we have previously found the key, return true
		if (x == dimension - 1 && y == dimension - 2) {
			if (found) {
				maze[x][y] = '1';
			}
			return found;
		}

		// Check if maze[x][y] is valid
		if (canMove(maze, found, x, y)) {

			char prev = maze[x][y];

			if(maze[x][y] == 'k') {
				found = true;
			} else {
				// mark x, y as part of solution path
				if (found) {
					maze[x][y] = '1';
				} else {
					maze[x][y] = '0';
				}
			}

			//Move right
			if (solveMazeUtil(maze, found, x + 1, y)) {
				return true;
				//Move left
			} else if (solveMazeUtil(maze, found, x - 1, y)) {
				return true;
				//Move downwards
			} else if (solveMazeUtil(maze, found, x, y + 1)) {
				return true;
				//Move upwards
			} else if (solveMazeUtil(maze, found, x, y - 1)) {
				return true;
				//If none of the above movements works then BACKTRACK: unmark x, y as part of solution path
			} else {
				maze[x][y] = prev;
				}
			}

		return false;
	}

	//Loads maze from text file
	char[][] loadMaze(String directory) throws IOException{
		char[][] maze = new char[dimension][dimension];

		try (BufferedReader br = new BufferedReader(new FileReader(directory))) {
			String line;
			int row = 0;
			while ((line = br.readLine()) != null) {
				for (int col = 0; col < line.length(); col++){
					maze[row][col] = line.charAt(col);
				}
				row++;
			}
		}
		return maze;

	}

	//Prints maze
	private static void printMaze(char[][] maze) {
		for (int i = 0; i < maze[0].length; i++) {
			for (int j = 0; j < maze[0].length; j++)
				System.out.print(" " + maze[i][j] + " ");
			System.out.println();
		}
		System.out.println();
	}


	public static void main(String args[]) {
		Maze m = new Maze();
		for (int i = 0; i < 12; i++) {
			try {
				char[][] myMaze = m.loadMaze("src/test/a3/mazes/m"+i+".txt");
				System.out.println("\nMaze "+i);
				Maze.printMaze(myMaze);
				if(m.solveMaze(myMaze)){
					Maze.printMaze(myMaze);
				}
			} catch (Exception e){
				System.out.print("File was not found.");
			}

		}
	}
}