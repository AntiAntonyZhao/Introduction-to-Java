package a3;

import java.util.Arrays;

public class ClosestAntennaPair {

    private double closestDistance = Double.POSITIVE_INFINITY;
    private long counter = 0;

    public ClosestAntennaPair(Point2D[] aPoints, Point2D[] bPoints) {

        int nA = aPoints.length;
        if (nA < 1) return;

        int nB = bPoints.length;
        if (nB < 1) return;

        // sort by x-coordinate (breaking ties by y-coordinate via stability)

        Point2D[] aPointsSortedByX = new Point2D[nA];
        for (int i = 0; i < nA; i++)
            aPointsSortedByX[i] = aPoints[i];

        Point2D[] bPointsSortedByX = new Point2D[nB];
        for (int i = 0; i < nB; i++)
            bPointsSortedByX[i] = bPoints[i];

        //  first sort by Y.   Then sort by X.  This ultimately sorts by x, with ties broken by the y value.
        //  this assumes that Arrays.sort() is a stable sort, namely that it doesn't swap ties, which indeed it is.

        Arrays.sort(aPointsSortedByX, Point2D.Y_ORDER);
        Arrays.sort(aPointsSortedByX, Point2D.X_ORDER);

        Arrays.sort(bPointsSortedByX, Point2D.Y_ORDER);
        Arrays.sort(bPointsSortedByX, Point2D.X_ORDER);

        // set up the array that eventually will hold the points sorted by y-coordinate

        Point2D[] aPointsSortedByY = new Point2D[nA];
        for (int i = 0; i < nA; i++)
            aPointsSortedByY[i] = aPointsSortedByX[i];

        Point2D[] bPointsSortedByY = new Point2D[nB];
        for (int i = 0; i < nB; i++)
            bPointsSortedByY[i] = bPointsSortedByX[i];

        // auxiliary array
        Point2D[] auxA = new Point2D[nA];
        Point2D[] auxB = new Point2D[nB];

        closest(aPointsSortedByX, bPointsSortedByX, aPointsSortedByY, bPointsSortedByY, auxA, auxB, 0, 0, nA - 1, nB - 1);
    }

    // find closest pair of points in aPointsSortedByX[lowA..highA] x bPointsSortedByX[lowB..highB]

    // precondition:  aPointsSortedByX[lowA..highA] and aPointsSortedByY[lowA..highA] are the same sequence of points, so are the ones for B.
    // precondition:  aPointsSortedByX[lowA..highA], bPointsSortedByX[lowB..highB] sorted by x-coordinate
    // postcondition: aPointsSortedByY[lowA..highA], bPointsSortedByY[lowB..highB] sorted by y-coordinate   <-   how this is done is subtle

    public double closest(Point2D[] aPointsSortedByX, Point2D[] bPointsSortedByX, Point2D[] aPointsSortedByY, Point2D[] bPointsSortedByY, Point2D[] auxA, Point2D[] auxB, int lowA, int lowB, int highA, int highB) {
        // please do not delete/modify the next line!
        counter++;

        // low and high refer to indices in the list of points.
        // base case 1: there is only one non-empty set of points
        if (highA < lowA) {
            Arrays.sort(bPointsSortedByY, lowB, highB + 1, Point2D.Y_ORDER);
            return Double.POSITIVE_INFINITY;
        }

        if (highB < lowB) {
            Arrays.sort(aPointsSortedByY, lowA, highA + 1, Point2D.Y_ORDER);
            return Double.POSITIVE_INFINITY;
        }

        // base case 2: in one of the sets there is only one point
        if (highA == lowA) {
            Point2D pointA = aPointsSortedByX[lowA];
            double minDistance = Double.POSITIVE_INFINITY;
            for (int i = lowB; i <= highB; i++) {
                double dist = bPointsSortedByX[i].distanceTo(pointA);
                if (dist < minDistance) {
                    minDistance = dist;
                }
            }
            return updateAndSort(aPointsSortedByY, bPointsSortedByY, lowA, lowB, highA, highB, minDistance);
        }

        if (highB == lowB) {
            Point2D pointB = bPointsSortedByX[lowB];
            double minDistance = Double.POSITIVE_INFINITY;
            for (int i = lowA; i <= highA; i++) {
                double dist = aPointsSortedByX[i].distanceTo(pointB);
                if (dist < minDistance) {
                    minDistance = dist;
                }
            }
            return updateAndSort(aPointsSortedByY, bPointsSortedByY, lowA, lowB, highA, highB, minDistance);
        }

        // recursive case
        int midAIndex = lowA + (highA - lowA) / 2;
        Point2D midAPoint = aPointsSortedByX[midAIndex];
        int midBIndex = lowB - 1;
        for (int i = lowB; i <= highB; i++) {
            Point2D point = bPointsSortedByX[i];
            if (point.x() <= midAPoint.x()) {
                midBIndex = i;
            } else
                break;
        }


        // compute closest pair with such that both points in the pair are either in left subarray or both points are in right subarray
        // the two closest calls below will return with aPointsSortedByY[lowA..midAIndex] x bPointsSortedByY[lowB..midBIndex]
        // and aPointsSortedByY[midAIndex+1 .. highA] x bPointsSortedByY[midBIndex+1..highB] sorted by Y
        // then the aPointsSortedByY will be merged so the range [lowA,highA] is sorted by Y, the same for B points.

        double delta1 = closest(aPointsSortedByX, bPointsSortedByX, aPointsSortedByY, bPointsSortedByY, auxA, auxB, lowA, lowB, midAIndex, midBIndex);
        double delta2 = closest(aPointsSortedByX, bPointsSortedByX, aPointsSortedByY, bPointsSortedByY, auxA, auxB, midAIndex + 1, midBIndex + 1, highA, highB);
        double delta = Math.min(delta1, delta2);

        // As mentioned above, now merge back so that aPointsSortedByY[lowA..highA] and bPointsSortedByY[lowB..highB] are sorted by y-coordinate.
        // We know the low < high.  Also see preconditions on merge().

        merge(aPointsSortedByY, auxA, lowA, midAIndex, highA);
        merge(bPointsSortedByY, auxB, lowB, midBIndex, highB);

        // The aux array has the same size as point2D[] but we only use the first hi-low+1 slots here.

        // auxA[0..mA-1] = go through the [lowA,highA] range of aPointsSortedByY and make a list of those points
        // whose x value is within delta from the median of x;  keep them sorted by y-coordinate
        // and do the same for points in bPointsSortedByY.
        // These are the points from both A and B in a 2-delta strip around the median A point in [lowA,highA].
        // Note this wipes out any values in aux that were previously there, which is fine since aux is temporary only.

        int mA = 0;
        for (int i = lowA; i <= highA; i++) {
            if (Math.abs(aPointsSortedByY[i].x() - midAPoint.x()) <= delta)
                auxA[mA++] = aPointsSortedByY[i];
        }

        // stores the B points lying within the strip
        int mB = 0;
        for (int i = lowB; i <= highB; i++) {
            if (Math.abs(bPointsSortedByY[i].x() - midAPoint.x()) <= delta) {
                auxB[mB++] = bPointsSortedByY[i];
            }
        }

        // Compare pairs of points within the strip;  we only need to test points with a y separation <= delta
        // Find the closest pair of points and return the distance between them
        // The two points are called bestA and bestB

        for (int i = 0; i < mA; i++) {
            for (int j = 0; (j < mB) && (auxB[j].y() - auxA[i].y() <= delta); j++) {
                double distance = auxA[i].distanceTo(auxB[j]);
                if (distance <= delta) {
                    delta = distance;
                    if (distance < closestDistance)
                        closestDistance = delta;
                }
            }
        }
        return delta;
    }

    private double updateAndSort(Point2D[] aPointsByY, Point2D[] bPointsByY, int lowA, int lowB, int highA, int highB, double minDistance) {
        if (minDistance < this.closestDistance)
            this.closestDistance = minDistance;
        Arrays.sort(aPointsByY, lowA, highA + 1, Point2D.Y_ORDER);
        Arrays.sort(bPointsByY, lowB, highB + 1, Point2D.Y_ORDER);
        return minDistance;
    }

    public double distance() {
        return closestDistance;
    }

    public long getCounter() {
        return counter;
    }

    // stably merge a[low .. mid] with a[mid+1 ..high] using aux[low .. high]
    // precondition: a[low .. mid] and a[mid+1 .. high] are sorted subarrays, namely sorted by y coordinate
    // this is the same as in ClosestPair
    private static void merge(Point2D[] a, Point2D[] aux, int low, int mid, int high) {
        // copy to aux[]
        // note this wipes out any values that were previously in aux in the [low,high] range we're currently using

        for (int k = low; k <= high; k++) {
            aux[k] = a[k];
        }

        int i = low, j = mid + 1;
        for (int k = low; k <= high; k++) {
            if (i > mid) a[k] = aux[j++];   // already finished with the low list ?  then dump the rest of high list
            else if (j > high) a[k] = aux[i++];   // already finished with the high list ?  then dump the rest of low list
            else if (aux[i].compareByY(aux[j]) < 0)
                a[k] = aux[i++]; // aux[i] should be in front of aux[j] ? position and increment the pointer
            else a[k] = aux[j++];
        }
    }
}
