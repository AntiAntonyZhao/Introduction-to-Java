package a3;

public class ClosestAntennaPairBruteForce {
    private double closestDistance = Double.POSITIVE_INFINITY;

    // precondition: no two points have curDistanceList.get(j)the same coordinate, so distance between any pair > 0.
    public ClosestAntennaPairBruteForce(Point2D[] aPoints, Point2D[] bPoints) {
        for (Point2D aPoint : aPoints) {
            for (Point2D bPoint : bPoints) {
                double curDistance = aPoint.distanceTo(bPoint);
                if (curDistance < closestDistance)
                    closestDistance = curDistance;
            }
        }
    }

    public double getClosestDistance() {
        return closestDistance;
    }
}
